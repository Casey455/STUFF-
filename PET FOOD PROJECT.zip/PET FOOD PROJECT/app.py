from flask import Flask, request, jsonify, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from apscheduler.schedulers.background import BackgroundScheduler
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///pet_treats.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

CORS(app)

db = SQLAlchemy(app)

# Models for the Treats and Breeds
class Treat(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    pet_type = db.Column(db.String(20), nullable=False)
    size = db.Column(db.String(20), nullable=False)
    breed = db.Column(db.String(50), nullable=True)
    diet = db.Column(db.String(50), nullable=True)

class Breed(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    pet_type = db.Column(db.String(20), nullable=False)
    breed_name = db.Column(db.String(50), nullable=False)

# Create the database and tables
with app.app_context():
    db.create_all()

# Function to update the data from the web
def update_data():
    url = "https://example.com/pet-treats"  # Replace with a real URL
    try:
        response = requests.get(url)
        response.raise_for_status()  # Check for request errors

        soup = BeautifulSoup(response.text, 'html.parser')

        # Example of parsing treats from the webpage
        for item in soup.find_all('div', class_='treat-item'):
            name = item.find('h2').text.strip()
            pet_type = item.find('span', class_='pet-type').text.strip()
            size = item.find('span', class_='size').text.strip()
            breed = item.find('span', class_='breed').text.strip()
            diet = item.find('span', class_='diet').text.strip()

            # Add new treat to the database
            new_treat = Treat(name=name, pet_type=pet_type, size=size, breed=breed, diet=diet)
            db.session.add(new_treat)

        db.session.commit()
        print("Database updated with new treats.")

    except Exception as e:
        print(f"Error fetching data: {e}")

# Scheduler setup to update every day at midnight
scheduler = BackgroundScheduler()
scheduler.add_job(func=update_data, trigger="interval", days=1)
scheduler.start()

# Flask routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/recommend', methods=['POST'])
def recommend_treats():
    data = request.json
    recommendations = []

    treats = Treat.query.filter_by(pet_type=data['petType'], size=data['size']).all()

    for treat in treats:
        if treat.breed == data['breed'] or treat.diet == data['diet']:
            recommendations.append(treat.name)

    if recommendations:
        return jsonify({"recommended_treats": recommendations})
    else:
        return jsonify({"message": "No suitable treats found."})

if __name__ == '__main__':
    app.run(debug=True)
