document.getElementById('petForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const petType = document.getElementById('petType').value;
    const weight = parseInt(document.getElementById('weight').value);
    const size = document.getElementById('size').value;
    const breed = document.getElementById('breed').value;
    const diet = document.getElementById('diet').value;

    const requestData = {
        petType: petType,
        weight: weight,
        size: size,
        breed: breed,
        diet: diet
    };

    fetch('/recommend', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestData)
    })
    .then(response => response.json())
    .then(data => {
        const recommendationsDiv = document.getElementById('recommendations');
        recommendationsDiv.innerHTML = ''; // Clear previous recommendations

        if (data.recommended_treats.length > 0) {
            recommendationsDiv.innerHTML = `<h2>Recommended Treats:</h2><ul>${data.recommended_treats.map(treat => `<li>${treat}</li>`).join('')}</ul>`;
        } else {
            recommendationsDiv.innerHTML = '<p>No suitable treats found.</p>';
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
});
